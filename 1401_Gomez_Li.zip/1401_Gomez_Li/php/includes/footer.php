<div class="footer">
    <pre id="footer-content">
        <b>Para mas informacion:</b>
        javier.gomezmartinez@estudiante.uam.es
        carlos.li@estudiante.uam.es</pre>
</div>